PLUGIN.name = "Fishing"
PLUGIN.author = "Nomas"
PLUGIN.desc = "An 1.2 fishing system."

